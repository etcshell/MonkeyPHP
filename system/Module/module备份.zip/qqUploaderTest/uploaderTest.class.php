<?php
!defined('in_monkey_php') && exit('Access Denied');
/**
 * uploaderTest
 * @category   测试上传功能
 * @package    上传
 * @author     HuangYi
 * @copyright  Copyright (c) 2012-4-1——至今
 * @license    New BSD License
 * @version    $Id: uploaderTest.class.php 版本号 2012-4-1 $
 *
 */
class uploaderTest {
    public static function get_upload_ui($handle){
        $qqUploaderClient=__index__.'/modules/qqUploader/client';
        mkLayout::add_link($qqUploaderClient.'/fileuploader.css');
        mkLayout::add_js_file($qqUploaderClient.'/fileuploader.js');
        mkLayout::set_title('测试文件上传');
        $qqTemplate=new mkTemplate(dirname(__FILE__));
        $qqTemplate->assign('qqUploader_receiver', $handle);
        return $qqTemplate->loading('/tpl/qqUpload_eg.htm',FALSE);
    }
    public static function upload_receiver(){
        // list of valid extensions, ex. array("jpeg", "xml", "bmp")
        $allowedExtensions = array();
        // max file size in bytes
        $sizeLimit = 10 * 1024 * 1024;//最大字节数，这是要和ini设置配合的，php.ini是全局的，可以设置大一点，这里是细化到每个具体上传点，设置小一点，倒过来不行哈
        $uploader = new qqFileUploader($allowedExtensions, $sizeLimit,  mkConfig::$ini['os_charset']);
        $result = $uploader->handle_upload(__dir_index__.'/upload/');
        // to pass data through iframe you will need to encode all html tags
        echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
    }
}