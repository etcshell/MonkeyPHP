<?php
!defined('in_monkey') && exit('Access Denied');
/**
 * Description of user
 *
 * @author hyiyou
 * user表用到的字段：
 *      uid, account, password, status（0代表禁用）
 * userlogin表用到的字段：
 *      uid, time（int）, ip
 *
 */
class user extends model {
    private static $_instance;
    /**
     * 获取多例
     * @param null $db_config
     */
    public function __construct($db_config = null) {
        $db=  creater::db($db_config);
        parent::__construct('user',$db);
    }
    /**
     * 获取单例（建议）
     * @param null|array $db_config 数据库配置
     * @return user
     */
    public static function get_instance($db_config = null){
        !self::$_instance and self::$_instance=new self($db_config);
        return self::$_instance;
    }

    /**
     * 登录系统，并记录到登录日志表中
     * @param $user
     * @param bool $is_verify
     * @return bool
     */
    public function login($user,$is_verify=false){
        if($is_verify && $user['verify']!==$_SESSION['verify_code'])return false;
        $user['password']=$this->make_password($user['account'],$user['password']);
        $user=$this->_curd
                ->where('account=<account> and password=<password>')
                ->select($user)
                ->result_fetch();
        if(empty($user)) return false;
        if(!$user['status']){
            $this->_error_massage='帐号已禁用！';
            return false;
        }
        $this->set_focus($user);
        $_SESSION['user']=$user;
        $this->_cacher->store('user_'.$user['uid'],$user);
        $userlogin_log_model=new model('userlogin');
        $userlogin_log_model->curd()->value(array(
            'uid'=>$user['uid'],
            'time'=>__time__,
            'ip'=>request::ip()
        ))->insert();
        unset($userlogin_log_model);
        return true;
    }

    /**
     * 登出系统
     */
    public static function logout(){
        unset($_SESSION['user']);
        session_destroy();
    }

    /**
     * 检查是否登录
     * @return bool
     */
    public function login_check(){
        if(empty($_SESSION['user'])) return false;
        $user=$_SESSION['user'];
        if(empty($user['uid'])) return false;
        $this->_cacher->fetch('user_'.$user['uid'],$user_dif);
        $user_dif=array_diff($user,$user_dif);
        if(!empty($user_dif)) return false;
        return true;
    }

    /**
     * 构造密码，默认密码为六个8
     * @param $account
     * @param string $password
     * @return string
     */
    public function make_password($account,$password='888888'){
        return md5($account.'monkey'.$password);
    }

    /**
     * 插入（默认密码为六个8）
     * @param array $user
     * @return bool
     */
    public function insert(array $user=null){
        $user && $this->set_focus($user);
        if(empty($this->_focus)) return false;
        if(empty($this->_focus['account']))return false;
        $this->_focus['password']=$this->make_password($this->_focus['account'], $this->_focus['password']);
        return $this->insert_focus();
    }

    /**
     * 仅更新
     * @param array $user
     * @return bool
     */
    public function update(array $user=null){
        $user && $this->set_focus($user);
        if(empty($this->_focus)) return false;
        return $this->update_focus();
    }

    /**
     * 更新并重置密码
     * @param array $user
     * @return bool
     */
    public function update_reset_password(array $user=null){
        $user && $this->set_focus($user);
        if(empty($this->_focus)) return false;
        if(empty($this->_focus['account']))return false;
        $this->_focus['password']=$this->make_password($this->_focus['account'], $this->_focus['password']);
        return $this->update_focus();
    }

    /**
     * 删除
     * @param array $user
     * @return bool
     */
    public function delete(array $user=null){
        $user && $this->set_focus($user);
        if(empty($this->_focus)) return false;
        return $this->delete_focus();
    }

    /**
     * 获取验证码
     */
    public static function get_verify(){
        $image=new image();
        $_SESSION['verify_code']=$image->make_verification_code();//生成的图像直接输出到浏览器了
        unset($image);
    }

    /**
     * 获取用户所属组
     * 写完用户组模块后写这个
     */
    public function get_group(){

    }

    /**
     * 获取用户角色
     * 写完角色模块后写这个
     * 后面没有了权限，因为只针对角色设置权限，不针对用户或组设置权限
     */
    public function get_role(){

    }
}
