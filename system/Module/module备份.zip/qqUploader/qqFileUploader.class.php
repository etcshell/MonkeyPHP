<?php
!defined('in_monkey_php') && exit('Access Denied');
/**
 * qqFileUploader
 * QQ邮箱的文件上传效果
 * @category   文件上传
 * @package    分享包
 * @author     HuangYi
 * @copyright  Copyright (c) 2012-4-1——至今
 * @license    New BSD License
 * @version    $Id: qqFileUploader.class.php 版本号 2012-4-1 $
 * 使用方法：
 * // list of valid extensions, ex. array("jpeg", "xml", "bmp")
 * $allowedExtensions = array();
 * // max file size in bytes
 * $sizeLimit = 10 * 1024 * 1024;
 * $uploader = new qqFileUploader($allowedExtensions, $sizeLimit,'GB2312');
 * $result = $uploader->handleUpload(__dir_index__.'/upload/');
 * // to pass data through iframe you will need to encode all html tags
 * echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
 *
 */
class qqFileUploader {
    private $_allowedExtensions = array();
    private $_sizeLimit = 10485760;
    private $_file;
    private $_system_charset='GB2312';
    /**
     * QQ上传
     * @param array $allowedExtensions 允许的扩展名
     * @param integer $sizeLimit 最大字节数，这是要和ini设置配合的，php.ini是全局的，可以设置大一点，这里是细化到每个具体上传点，设置小一点，倒过来不行哈
     */
    public function __construct(array $allowedExtensions = array(),$sizeLimit = 10485760){
        $this->_system_charset = DIRECTORY_SEPARATOR=='\\'?'GB2312':'utf-8';
        $allowedExtensions = array_map("strtolower", $allowedExtensions);
        $this->_allowedExtensions = $allowedExtensions;
        $this->_sizeLimit = $sizeLimit;
        $this->_checkServerSettings();
        if (isset($_GET['qqfile'])) {
            $this->_file = new qqUploadedFileXhr();
        } elseif (isset($_FILES['qqfile'])) {
            $this->_file = new qqUploadedFileForm();
        } else {
            $this->_file = false;
        }
    }
    private function _checkServerSettings(){
        $postSize = $this->_toBytes(ini_get('post_max_size'));
        $uploadSize = $this->_toBytes(ini_get('upload_max_filesize'));
        if ($postSize < $this->_sizeLimit || $uploadSize < $this->_sizeLimit){
            $size = max(1, $this->_sizeLimit / 1024 / 1024) . 'M';
            die("{'error':'increase post_max_size and upload_max_filesize to $size'}");
        }
    }
    private function _toBytes($str){
        $val = trim($str);
        $last = strtolower($str[strlen($str)-1]);
        switch($last) {
            case 'g': $val *= 1024;
            case 'm': $val *= 1024;
            case 'k': $val *= 1024;
        }
        return $val;
    }
    /**
     * Returns array('success'=>true) or array('error'=>'error message')
     */
    /**
     * 处理上传文件
     * @param string $uploadDir 保存上传文件的目录
     * @param bool $replaceOldFile 是否覆盖同名文件
     * @return array('success'=>true) or array('error'=>'error message')
     */
    public function handle_upload($uploadDir, $replaceOldFile = FALSE){
        if(substr($uploadDir,-1)!='/' ) $uploadDir.='/';
        mk_dir_check($uploadDir);
        if (!is_writable($uploadDir)){
            return array('error' => "Server error. Upload directory isn't writable.");
        }
        if (!$this->_file){
            return array('error' => 'No files were uploaded.');
        }
        $size = $this->_file->get_size();
        if ($size == 0) {
            return array('error' => 'File is empty');
        }
        if ($size > $this->_sizeLimit) {
            return array('error' => 'File is too large');
        }
        $pathinfo = pathinfo($this->_file->get_name());
        $extLen=  strlen($pathinfo['extension'])+1;
        $basename=  substr($this->_file->get_name(), 0, 0-$extLen);
        if($this->_system_charset=='GB2312'){
            $basename=iconv("UTF-8","GB2312//IGNORE",$basename);
        }
        //$filename = md5(uniqid());
        $ext = $pathinfo['extension'];
        if($this->_allowedExtensions && !in_array(strtolower($ext), $this->_allowedExtensions)){
            $these = implode(', ', $this->_allowedExtensions);
            return array('error' => 'File has an invalid extension, it should be one of '. $these . '.');
        }
        if(!$replaceOldFile){
            /// don't overwrite previous files that were uploaded
            while (file_exists($uploadDir . $basename . '.' . $ext)) {
                $basename .= rand(10, 99);
            }
        }

        if ($this->_file->save($uploadDir . $basename . '.' . $ext)){
            return array('success'=>true);
        } else {
            return array('error'=> 'Could not save uploaded file.' .
                'The upload was cancelled, or server error encountered');
        }
    }
}
/**
 * Handle file uploads via XMLHttpRequest
 */
class qqUploadedFileXhr {
    /**
     * Save the file to the specified path
     * @return boolean TRUE on success
     */
    public function save($path) {
        $input = fopen("php://input", "r");
        $temp = tmpfile();
        $realSize = stream_copy_to_stream($input, $temp);
        fclose($input);

        if ($realSize != $this->get_size()){
            return false;
        }

        $target = fopen($path, "w");
        fseek($temp, 0, SEEK_SET);
        stream_copy_to_stream($temp, $target);
        fclose($target);

        return true;
    }
    public function get_name() {
        return $_GET['qqfile'];
    }
    public function get_size() {
        if (isset($_SERVER["CONTENT_LENGTH"])){
            return (int)$_SERVER["CONTENT_LENGTH"];
        } else {
            throw new Exception('Getting content length is not supported.');
        }
    }
}
/**
 * Handle file uploads via regular form post (uses the $_FILES array)
 */
class qqUploadedFileForm {
    /**
     * Save the file to the specified path
     * @return boolean TRUE on success
     */
    public function save($path) {
        if(!move_uploaded_file($_FILES['qqfile']['tmp_name'], $path)){
            return false;
        }
        return true;
    }
    public function get_name() {
        return $_FILES['qqfile']['name'];
    }
    public function get_size() {
        return $_FILES['qqfile']['size'];
    }
}