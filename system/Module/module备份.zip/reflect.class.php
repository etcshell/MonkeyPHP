<?php
/**
 * 类映射
 * @copyright Copyright &copy; 2011, MAOJIAN
 * @author maojianlw@139.com
 * @since 1.0 - 2011-10-15
 */
class reflect{
    public $reflect = null;
    public $file_arr = null;
    public $file_fun_arr = null;
    /**
     * 初始化类
     */
    public function __construct($class_name, $file_arr=array()) {
        if(!empty($class_name)){
            $this->file_arr = $file_arr;
            $this->reflect = new ReflectionClass($class_name);
        }
    }
    /**
     * 获取类的名称
     */
    public function get_name(){
        return $this->reflect->getName();
    }
    /**
     * 获得类的所有方法
     */
    public function get_methods(){
        $methods = $this->reflect->getMethods();
        if(is_array($methods)){
            foreach($methods as $method){
                $declaring_class = $method->getDeclaringClass();
                if($declaring_class->name == $this->get_name()){
                    $comment_arr[] = $this->get_doc_comment($method, false);
                }
            }
        }
        return $comment_arr;
    }
    /**
     * 获得对象注释
     */
    public function get_doc_comment($obj, $isClass = true, $isFun = false){
        $comment = $obj->getDocComment();
        $comment_arr['name'] = $obj->name;
        if(!empty($comment)){
            $comment = str_replace(chr(10), '', $comment);
            $comments = array_unique(explode('*', $comment));
            $size = count($comments);

            if($isClass){ // 对象类
                foreach($comments as $val){
                    $val = trim($val);
                    if(!empty($val) && $val!='/'){
                        if(strpos($val, '@') === 0){
                            $val = substr($val, 1);
                        }
                        $val = htmlspecialchars($val);
                        $remark[] = "{$val}";
                    }
                }
                $comment_arr['comment'] = $remark;
            }else{  // 类方法或者函数
                $comment_params = array();
                foreach($comments as $k=>$val){
                    $val = trim($val);
                    if(!empty($val) && $val!='/'){
                        if(strpos($val, '@param') === 0){
                            $param_arr = explode(' ', $val);
                            $param_name = str_replace('$', '', $param_arr[2]);
                            $desc = $param_arr[3];
                            $size = count($param_arr);

                            if($size > 4){
                                for($i=4; $i<=($size-1); $i++){
                                    $desc .= ' '.$param_arr[$i];
                                }
                                $desc = htmlspecialchars($desc);
                            }

                            $comment_params[$param_name] = array('type'=>$param_arr[1], 'desc'=>$desc);
                        }else if(strpos($val, '@return') === 0){
                            $return_arr = explode(' ', $val);
                            $comment_arr['return'] = array('type'=>strtolower($return_arr[1]), 'desc'=>$return_arr[2]);
                        }else{
                            $remark .= "{$val}, ";
                        }
                    }
                }
                $comment_arr['comment'] = rtrim($remark, ', ');
            }
        }
        if(!$isClass){
            // 参数匹配
            $method_params = $obj->getParameters();
            if(is_array($method_params) && count($method_params) > 0){
                foreach($method_params as $param){
                    $param__name = $param->name;
                    if($comment_params && array_key_exists($param__name, $comment_params)){
                        $type = $comment_params[$param__name]['type'];
                        $desc = $comment_params[$param__name]['desc'];
                    }else{
                        $type = 'mixed';
                        $desc = '';
                    }
                    // 是否是可选项,获取默认值
                    $value = ($option = $param->isOptional()) ? $param->getDefaultValue() : '';
                    if(!empty($value)){
                        $value = htmlspecialchars($value);
                    }
                    $refer = $param->isPassedByReference();
                    $params[] = array('name'=>$param__name, 'type'=>strtolower($type), 'desc'=>$desc, 'value'=>$value, 'option'=>$option, 'refer'=>$refer);
                }
                $comment_arr['params'] = $params;
            }
            // 函数没有此项修饰符
            if(!$isFun){
                $comment_arr['modifiers'] = Reflection::getModifierNames($obj->getModifiers());
            }
            $start_line = $obj->getStartLine()-1;
            $end_line = $obj->getEndLine();
            $comment_arr['source'] = $this->get_high_light_str($start_line, $end_line, (($isFun) ? $this->file_fun_arr : $this->file_arr));
        }else{
            /**
             * 属性列表
             */
            $properties = $obj->getProperties();
            if(is_array($properties)){
                foreach($properties as $p){
                    $declaring_class = $p->getDeclaringClass();
                    if($declaring_class->name != $this->get_name()){
                        continue;
                    }
                    $p_comment = $p->getDocComment();
                    if(!empty($p_comment)){
                        $p_comment = str_replace('*', '', $p_comment);
                        $p_comment = str_replace('/', '', $p_comment);
                        $p_comment = htmlspecialchars($p_comment);
                    }
                    $modifier_arr = Reflection::getModifierNames($p->getModifiers());
                    $p->setAccessible(true);

                    $value = ($p->isDefault()) ? $p->getValue($obj) : '';
                    if(!is_string($value)){
                        $value = '';
                    }else if(!empty($value)){
                        $value = htmlspecialchars($value);
                    }
                    $proper_arr[] = array('name'=>$p->name, 'comment'=>$p_comment, 'modifier'=>implode(' ', $modifier_arr), 'value'=>$value);
                }
                $comment_arr['properties'] = $proper_arr;
            }
            /**
             * 获取父类
             */
            $parent_class = $obj->getParentClass();
            $comment_arr['parent'] = $parent_class->name;
            /**
             * 预定义常量列表
             */
            $constants = $obj->getConstants();
            $comment_arr['constants'] = $constants;
        }
        return $comment_arr;
    }
    /**
     * 获得高亮显示的字符串
     */
    protected function get_high_light_str($start_line, $end_line, $file_arr){
        $source='';
        for($i=$start_line; $i<=$end_line; $i++){
            $source .= $file_arr[$i];
        }
        // 获取类方法源码
        $source = highlight_string("<?php \r\n{$source}\r\n?>", true);
        $search = '&lt;?php&nbsp;';
        $source = str_replace($search, '', $source);
        $search = '?&gt;';
        $source = str_replace($search, '', $source);

        return $source;
    }
    /**
     * 获得所有用户自定义函数
     */
    public function get_functions($fun_file){
        $functions = get_defined_functions();
        $fun_arr = $functions['user'];
        if(is_array($fun_arr)){
            foreach($fun_arr as $fun){
                $funObj = new ReflectionFunction($fun);
                $file_name = $funObj->getFileName();
                if(strtolower($file_name) == strtolower($fun_file)){
                    $this->file_fun_arr = file($file_name);
                    $fun_info_arr[] = $this->get_doc_comment($funObj, false, true);
                }
            }
        }
        return $fun_info_arr;
    }
}