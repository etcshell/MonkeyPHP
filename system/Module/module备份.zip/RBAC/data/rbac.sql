-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2012 年 04 月 05 日 05:06
-- 服务器版本: 5.5.16
-- PHP 版本: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+08:00";

--
-- 数据库: `test`
--

-- --------------------------------------------------------

--
-- 超级管理员表的结构 `supperadmin`
--

CREATE TABLE IF NOT EXISTS `mk_supperadmin` (
  `sid` int(8) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(30) NOT NULL COMMENT '管理员用户名',
  `adminpwd` varchar(32) NOT NULL COMMENT '管理员密码',
  `is_mar` enum('Y','N') NOT NULL COMMENT '是否最高超级管理员',
  `realname` varchar(30) NOT NULL COMMENT '管理员实名',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='超级管理员' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 用户表的结构 `user` ,这个表可以增加字段，只要保证原有的字段不变即可
--

CREATE TABLE IF NOT EXISTS `mk_user` (
  `uid` int(8) NOT NULL AUTO_INCREMENT,
  `account` varchar(30) NOT NULL COMMENT '账号',
  `password` varchar(32) NOT NULL COMMENT '用户密码',
  `name` varchar(30) NOT NULL COMMENT '用户名字',
  `email` varchar(30) NOT NULL COMMENT '邮件',
  `is_action` enum('Y','N') NOT NULL COMMENT '是否激活',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 用户角色表的结构 `userrole`
--

CREATE TABLE IF NOT EXISTS `mk_userrole` (
  `urid` int(8) NOT NULL AUTO_INCREMENT,
  `uid` int(8) NOT NULL COMMENT '用户id',
  `rid` int(8) NOT NULL COMMENT '身份ID',
  `start` int(10) NOT NULL COMMENT '开始日期',
  `end` int(10) NOT NULL COMMENT '结束日期',
  PRIMARY KEY (`urid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 组管理表的结构 `group`
--

CREATE TABLE IF NOT EXISTS `mk_group` (
  `gid` int(8) NOT NULL AUTO_INCREMENT,
  `g_name` varchar(30) NOT NULL COMMENT '组名字',
  `admin_uid` int(8) NOT NULL COMMENT '组属管理员',
  `dest` varchar(256) NOT NULL COMMENT '说明',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='组管理' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 用户分组表的结构 `usergroup`（同一组用户的权限相同）
--

CREATE TABLE IF NOT EXISTS `mk_usergroup` (
  `ugid` int(8) NOT NULL AUTO_INCREMENT,
  `uid` int(8) NOT NULL COMMENT '用户ID',
  `gid` int(8) NOT NULL COMMENT '组ID',
  `adduid` int(8) NOT NULL COMMENT '谁添加的',
  PRIMARY KEY (`ugid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户分组表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 组角色分配表的结构 `grouprole`（每个组分配了哪些角色权限）
--

CREATE TABLE IF NOT EXISTS `mk_grouprole` (
  `grid` int(8) NOT NULL AUTO_INCREMENT,
  `gid` int(8) NOT NULL COMMENT '组ID',
  `rid` int(8) NOT NULL COMMENT '角色ID',
  `enable` enum('Y','N') NOT NULL COMMENT '是否启用此角色分配',
  PRIMARY KEY (`grid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='组角色分配表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 角色表的结构 `role`
--

CREATE TABLE IF NOT EXISTS `mk_role` (
  `rid` int(8) NOT NULL AUTO_INCREMENT,
  `r_name` varchar(30) NOT NULL COMMENT '角色名字',
  `is_mar` enum('Y','N') NOT NULL COMMENT '是否管理员',
  `dest` varchar(255) NOT NULL COMMENT '说明',
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------
-- --------------------------------------------------------
-- --------------------------------------------------------
--
-- 角色授权表的结构 `authorize` （为角色授予访问行为）
--

CREATE TABLE IF NOT EXISTS `mk_authorize` (
  `aid` int(8) NOT NULL AUTO_INCREMENT,
  `rid` int(8) NOT NULL COMMENT '角色ID',
  `bid` int(8) NOT NULL COMMENT '访问行为ID',
  `start` int(10) NOT NULL COMMENT '开始日期',
  `end` int(10) NOT NULL COMMENT '结束日期',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色授权表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 访问行为表的结构 `behaviour`（为每个资源的建立不同的访问行为）
--

CREATE TABLE IF NOT EXISTS `mk_behaviour` (
  `bid` int(8) NOT NULL AUTO_INCREMENT,
  `behaviour` char(50) NOT NULL COMMENT '行为名称',
  `rtid` int(8) NOT NULL COMMENT '资源类型ID',
  `oid` int(8) NOT NULL COMMENT '操作ID',

--安全级别有五态，这里不是绝对的，还要与系统的安全级别比较，谁高依谁，
--0：最低级别，没有明确授权，则视为有权，
--1：较低级别，有明确的允许，则视为有权，
--2：标准级别，依所有明确的判断，无资源为有权
--3：较高级别，有明确的拒绝，则视为无权，
--4：最高级别，没有明确授权，则视为无权，
  `safe_level` tinyint(1) NOT NULL DEFAULT 2 COMMENT '安全级别',

--自身操作自身有四态
--0：还要看绿卡和黑名单
--1：可以自己操作，不论绿卡和黑名单，是自身操作则有权
--2：只能自己操作，不是自身操作则无权
--3：禁止自己操作，是自身操作则无权
  `on_self` tinyint(1) NOT NULL DEFAULT 0 COMMENT '自身操作自身',

--黑名单（负向授权）有4个二进制位
--0001 1禁止超级管理员
--0010 2禁止组管理员，见black_groupadmin字段,'all'为所有组管理员
--0100 4禁止特定的组，见black_group字段
--1000 8禁止特定的角色，见black_role字段
  `black` tinyint(1) NOT NULL DEFAULT 0 COMMENT '黑名单（负向授权）',
  `black_groupadmin` varchar(255)  NULL COMMENT '黑名单组管理员',
  `black_group` varchar(255)  NULL COMMENT '黑名单组',
  `black_role` varchar(255)  NULL COMMENT '黑名单角色',

--绿卡（正向授权）有6个二进制位
--000001 1必须要登录
--000010 2必须要访问密码，见password字段
--000100 4必须要超级管理员
--001000 8必须要组管理员，见green_groupadmin字段,'all'为所有组管理员
--010000 16必须要特定的组，见green_group字段
--100000 32必须要特定的角色，见green_role字段
  `green` tinyint(1)  NOT NULL DEFAULT 0 COMMENT '绿卡（正向授权）',
  `password` varchar(32)  NULL COMMENT '访问密码',
  `green_groupadmin` varchar(255)  NULL COMMENT '允许的组管理员',
  `green_group` varchar(255)  NULL COMMENT '允许的组',
  `green_role` varchar(255)  NULL COMMENT '允许的角色',

--周期授权，有3个二进制位，见之后的字段
--001 1必须要每月某日许可
--010 2必须要每周某日许可（星期一=1，……星期天=7）
--100 4必须要每天某时许可
  `period` tinyint(1)  NOT NULL DEFAULT 0 COMMENT '周期授权',
  `daystart` int(2)  NULL COMMENT '每月开始日期',
  `dayend` int(2)  NULL COMMENT '每月结束日期',
  `weekstart` tinyint(1)  NULL COMMENT '每周开始星期',
  `weekend` tinyint(1)  NULL COMMENT '每周结束星期',
  `timestart` int(10)  NULL COMMENT '每天开始时间',
  `timeend` int(10)  NULL COMMENT '每天结束时间',
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='访问行为表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 资源类型表的结构 `resourcetype`
--

CREATE TABLE IF NOT EXISTS `mk_resourcetype` (
  `rtid` int(8) NOT NULL auto_increment COMMENT '资源类型id',
  `rt_name` varchar(50) NOT NULL COMMENT '资源类型名称',
  `dest` varchar(300) NOT NULL COMMENT '说明',
  PRIMARY KEY  (`rtid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源类型表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 操作表的结构 `operation`
--

CREATE TABLE IF NOT EXISTS `mk_operation` (
  `oid` int(8) NOT NULL auto_increment COMMENT '操作id',
  `o_name` varchar(50) NOT NULL COMMENT '操作名称',
  `dest` varchar(300) NOT NULL COMMENT '说明',
  PRIMARY KEY  (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作表' AUTO_INCREMENT=1 ;
