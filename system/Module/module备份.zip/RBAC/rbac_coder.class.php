<?php
!defined('in_monkey') && exit('Access Denied');
/**
 * rbac_coder
 * @category   行为字段编码解码器
 * @package    权限包
 * @author     HuangYi
 * @copyright  Copyright (c) 2012-7-1- <www.XXXXX.com>
 * @license    New BSD License
 * @version    $Id: rbac_coder.class.php 版本号 2012-7-1_10:43:09  $
 *
 */
class rbac_coder {
    /**
     * 对周期授权设置编码
     * @param bool $day 是否只允许每月的某些天
     * @param bool $week 是否只允许每周的某些天
     * @param bool $time 是否只允许每天的某些时间
     * @return int
     */
    public static function period_encode($day=FALSE,$week=FALSE,$time=FALSE){
        $period=0;
        if($day) $period+=1;
        if($week) $period+=2;
        if($time) $period+=4;
        return $period;
    }
    /**
     * 对周期授权设置解码
     * @param integer $period
     * @return Array =array('day','week','time')且每一项都是bool型
     */
    public static function period_decode($period){
        $period_array=array();
        $period_array['day']=(bool)$period&1;
        $period_array['week']=(bool)$period&2;
        $period_array['time']=(bool)$period&4;
        return $period_array;
    }
    /**
     * 对黑名单设置编码
     * @param bool $supper 是否禁止超级管理员
     * @param bool $groupadmin 是否禁止特定的组的管理员
     * @param bool $group 是否禁止特定的组
     * @param bool $role 是否禁止特定的角色
     * @return int
     */
    public static function black_encode($supper=FALSE,$groupadmin=FALSE,$group=FALSE,$role=FALSE){
        $black=0;
        if($supper) $black+=1;
        if($groupadmin) $black+=2;
        if($group) $black+=4;
        if($role) $black+=8;
        return $black;
    }
    /**
     * 对黑名单设置解码
     * @param integer $black
     * @return Array =array('supper','groupadmin','group','role')且每一项都是bool型
     */
    public static function black_decode($black){
        $black_array=array();
        $black_array['supper']=(bool)$black&1;
        $black_array['groupadmin']=(bool)$black&2;
        $black_array['group']=(bool)$black&4;
        $black_array['role']=(bool)$black&8;
        return $black_array;
    }
    /**
     * 对绿卡设置编码
     * @param bool $login 是否只给登录用户发绿卡
     * @param bool $password 是否只给有访问密码的用户发绿卡
     * @param bool $supper 是否只给超级管理员发绿卡
     * @param bool $groupadmin 是否只给特定的组管理员发绿卡
     * @param bool $group 是否只给特定的组发绿卡
     * @param bool $role 是否只给特定的角色发绿卡
     * @return int
     */
    public static function green_encode($login=FALSE,$password=FALSE,$supper=FALSE,$groupadmin=FALSE,$group=FALSE,$role=FALSE){
        $green=0;
        if($login) $green+=1;
        if($password) $green+=2;
        if($supper) $green+=4;
        if($groupadmin) $green+=8;
        if($group) $green+=16;
        if($role) $green+=32;
        return $green;
    }
    /**
     * 对绿卡设置解码
     * @param integer $green
     * @return Array =array('login','password','supper','groupadmin','group','role')且每一项都是bool型
     */
    public static function green_decode($green){
        $green_array=array();
        $green_array['login']=(bool)$green&1;
        $green_array['password']=(bool)$green&2;
        $green_array['supper']=(bool)$green&4;
        $green_array['groupadmin']=(bool)$green&8;
        $green_array['group']=(bool)$green&16;
        $green_array['role']=(bool)$green&32;
        return $green_array;
    }
}