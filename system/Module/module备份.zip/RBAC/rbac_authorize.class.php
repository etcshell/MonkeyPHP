<?php
!defined('in_monkey') && exit('Access Denied');
/**
 * rbac_authorize
 * @category   访问授权
 * @package    权限包
 * @author     HuangYi
 * @copyright  Copyright (c) 2012-4-1——至今
 * @license    New BSD License
 * @version    $Id: rbac_authorize.class.php 版本号 2012-4-1 $
 *
 */
class rbac_authorize {
    private $_sys_safe_level;//安全级别，冲突或疑难情况时执行的标准
    private $_rbac_reader;//访问控制器
    private $_error_code;//错误消息
    private $_cacher;//缓存对象
    private $_coder;//字段编码解码器

    const highest=4;
    const high=3;
    const normal=2;
    const low=1;
    const lowest=0;
    /**
     * 访问授权
     * @param integer $sys_safe_level 0|1|2|3|4，系统安全级别,默认为2标准，详见数据库设计
     * @param array $rbac_db_read_config 权限库读取配置
     * @param array $cache_config 权限缓存读取配置
     */
    public function __construct($sys_safe_level=2,array $rbac_db_read_config=null,array $cache_config=null){
        $this->_sys_safe_level=$sys_safe_level;
        $this->_rbac_reader=new rbac_reader($rbac_db_read_config,$cache_config);
        $this->_cacher= creater::cacher('rbac_authorize',$cache_config);
        $this->_coder=new rbac_coder();
    }
    /**
     * 获取权限读取器类
     * @return rbac_reader
     */
    public function get_rbac_reader(){
        return $this->_rbac_reader;
    }
    /**
     * 获取错误信息
     * @staticvar array $error_list
     * @return string
     */
    public function get_error_message(){
        static $error_list=array(
            'needlogin'=>'你的行为需要登录',
            'notfind'=>'当前行为没有登记，高安全级别下不用许访问！',
            'stopsupper'=>'当前行为禁止超级管理员访问！',
            'stopday'=>'当前访问行为不在规定的日期范围之内',
            'stopweek'=>'当前访问行为不在规定的星期范围之内',
            'stoptime'=>'当前访问行为不在规定的小时范围之内',
            'needpassword'=>'此行为需要单独的访问密码',
            'errorpassword'=>'请输入正确的行为密码',
            'onlyowner'=>'该行为只能由资源的所有人执行',
            'stopowner'=>'该行为需要资源的所有人回避',
            'onlysupper'=>'当前行为只允许超级管理员访问！',
            'stopblackgroupadmin'=>'你在该行为的组管理员黑名单中！',
            'stopgreengroupadmin'=>'你没有该行为的组管理员绿卡！',
            'stopblackgroup'=>'你在该行为的组黑名单中！',
            'stopgreengroup'=>'你没有该行为的组绿卡！',
            'stopblackrole'=>'你在该行为的角色黑名单中！',
            'stopgreenrole'=>'你没有该行为的角色绿卡！',
            'stopauthorize'=>'你没有获得该行为的授权，或其他类似错误！',
            'successful'=>'恭喜你，授权成功！',
        );
        return $error_list[$this->_error_code];
    }
    /**
     * 超级管理的权限检测
     * @param array $a_user 用户信息array('uid'=>id,'access_password'=>password,...)
     * @param array $a_resource 资源信息array('rtid'=>rtid,'ownerid'=>ownerid,...)
     * @param integer $i_operationid 操作ID
     * @return bool 有权限为True，无权限为False
     */
    public function check_supperadmin($a_user,$a_resource,$i_operationid){
        return $this->_cache_check('_check_supperadmin',$a_user,$a_resource,$i_operationid);
    }
    private function _check_supperadmin($a_user,$a_resource,$i_operationid){
        $this->_error_code='successful';
        //效验登录
        //超级管理员一定需要登录
        if(empty($a_user['uid'])){
            $this->_error_code='needlogin';
            return FALSE;
        }
        //首先查找访问行为，唯一。结果有则继续，无则根据安全级别授权
        $behaviour=array();
        if(!$this->_rbac_reader->get_behaviour($a_resource['rtid'], $i_operationid,$behaviour)){
            if($this->_sys_safe_level>self::normal){
                $this->_error_code='notfind';
                return FALSE;
            }
        }
//        $safe_level=  max($behaviour['safe_level'],  $this->_sys_safe_level);
        //解码黑名单
        $black=rbac_coder::black_decode($behaviour['black']);
        if($black['supper']){
            $this->_error_code='stopsupper';
            return FALSE;
        }
        //验证周期授权
        if(!$this->_check_period($behaviour))return FALSE;
        //解码绿卡
        $green=  rbac_coder::black_decode($behaviour['green']);
        if($green['password']){
            if($behaviour['password']!=$a_user['access_password']){
                if(empty($a_user['access_password'])) {
                    $this->_error_code='needpassword';
                }  else {
                    $this->_error_code='errorpassword';
                }
                return FALSE;
            }
        }
        //验证针对自身的操作
        switch ($behaviour['on_self']) {
            case 2://只能自己操作，不是自身操作则无权
                if($a_user['uid']!=$a_resource['ownerid']){
                    $this->_error_code='onlyowner';
                    return FALSE;
                }
                break;
            case 3://禁止自己操作，是自身操作则无权
                if($a_user['uid']==$a_resource['ownerid']){
                    $this->_error_code='stopowner';
                    return FALSE;
                }
                break;
            default:break;
        }
        return TRUE;
    }
    /**
     * 权限检测
     * @param array $a_user 用户信息array('uid'=>id,'access_password'=>password,...)
     * @param array $a_resource 资源信息array('rtid'=>rtid,'ownerid'=>ownerid,...)
     * @param integer $i_operationid 操作ID
     * @return bool 有权限为True，无权限为False
     */
    public function check_permission($a_user,$a_resource,$i_operationid){
            return $this->_cache_check('_check_permission',$a_user,$a_resource,$i_operationid);
    }
    private function _check_permission($a_user,$a_resource,$i_operationid){
        $this->_error_code='successful';
        //首先查找访问行为，唯一。结果有则继续，无则根据安全级别授权
        $behaviour=array();
        if(!$this->_rbac_reader->get_behaviour($a_resource['rtid'], $i_operationid,$behaviour)){
            if($this->_sys_safe_level>self::normal){
                $this->_error_code='notfind';
                return FALSE;
            }
        }
        $safe_level=  max($behaviour['safe_level'],  $this->_sys_safe_level);
        //验证周期授权
        if(!$this->_check_period($behaviour))return FALSE;
        //解码绿卡
        $green=  rbac_coder::black_decode($behaviour['green']);
        //验证只允许超管
        if($green['supper']){
            $this->_error_code='onlysupper';
            return FALSE;
        }
        //验证登录
        if(!$green['login']){
            return TRUE;//不需要登录就直接返回真了
        }elseif(empty($a_user['uid'])){
            $this->_error_code='needlogin';
            return FALSE;//需要登录而没有登录
        }
        //验证独立密码
        if($green['password']){
            if($behaviour['password']!=$a_user['access_password']){
                if(empty($a_user['access_password'])) {
                    $this->_error_code='needpassword';
                }  else {
                    $this->_error_code='errorpassword';
                }
                return FALSE;
            }
        }
        //效验针对自身的操作
        switch ($behaviour['on_self']) {
            case 1://可以自己操作，是自身操作则不论绿卡和黑名单
                if($a_user['uid']==$a_resource['ownerid']){
                    return TRUE;
                }
                break;
            case 2://只能自己操作，不是自身操作则无权
                if($a_user['uid']!=$a_resource['ownerid']){
                    $this->_error_code='onlyowner';
                    return FALSE;
                }  elseif($safe_level<self::normal) {
                    return TRUE;
                }
                break;
            case 3://禁止自己操作，是自身操作则无权
                if($a_user['uid']==$a_resource['ownerid']){
                    $this->_error_code='stopowner';
                    return FALSE;
                }
                break;
            default:break;
        }
        //效验角色授权
        $is_authorize=  $this->_rbac_reader->user_is_authorize($user_id, $behaviour['bid']);
        if(!$is_authorize){
            $this->_error_code='stopauthorize';
            return FALSE;
        }
        //解码黑名单
        $black=rbac_coder::black_decode($behaviour['black']);
        //效验组管理员
        $user_owner_group= $this->_rbac_reader->get_owner_group($a_user['uid']);
        if($black['groupadmin']
           && $this->_array_item_in_string($user_owner_group,$behaviour['black_groupadmin'])){
                $this->_error_code='stopblackgroupadmin';
                return FALSE;
        }
        if($green['groupadmin']
           && !$this->_array_item_in_string($user_owner_group,$behaviour['green_groupadmin'])){
                $this->_error_code='stopgreengroupadmin';
                return FALSE;
        }
        //效验组
        $user_group=$this->_rbac_reader->get_user_group($a_user['uid']);
        if($black['group']
           && $this->_array_item_in_string($user_group,$behaviour['black_group'])){
                $this->_error_code='stopblackgroup';
                return FALSE;
        }
        if($green['group']
           && !$this->_array_item_in_string($user_group,$behaviour['green_group'])){
                $this->_error_code='stopgreengroup';
                return FALSE;
        }
        //效验角色
        $user_role=$this->_rbac_reader->get_user_role($a_user['uid']);
        if($black['role']
           && $this->_array_item_in_string($user_role,$behaviour['black_role'])){//要求验证黑名单
                $this->_error_code='stopblackrole';
                return FALSE;
        }
        if($green['role']
           && !$this->_array_item_in_string($user_role,$behaviour['green_role'])){//要求验证绿卡
                $this->_error_code='stopgreenrole';
                return FALSE;
        }
        return true;
    }
    private function _check_period($behaviour){
        //解码周期授权
        $period=  rbac_coder::period_decode($behaviour['period']);
        if($period['day']){
            //必须要每月某日许可
            $day=date('j');
            if($day<$behaviour['daystart'] || $behaviour['dayend'] < $day){
                $this->_error_code='stopday';
                return FALSE;
            }
        }
        if($period['week']){
            //必须要每周某日许可（星期一=1，……星期天=7）
            $week=date('N');
            if($week<$behaviour['weekstart'] || $behaviour['weekend'] < $week){
                $this->_error_code='stopweek';
                return FALSE;
            }
        }
        if($period['time']){
            //必须要每天某时许可
            $todaybegin=  mktime(0, 0, 0);
            $now= __time__;
            $time=$now-$todaybegin;
            if($time<$behaviour['timetart'] || $behaviour['timeend'] < $time){
                $this->_error_code='stoptime';
                return FALSE;
            }
        }
    }
    private function _array_item_in_string($array,$string){
        if(empty($string)){//字符串是空的，数组项目存在就返回真
            if(empty($array)){//数组项目不存在
                return FALSE;
            }  else {//数组项目存在
                return TRUE;
            }
        }  else {//字符串是非空的，部分数组项目列入字符串
            if(empty($array)){//数组项目不存在
                return FALSE;
            }  else {//数组项目存在
                $string_to_array=explode(',',$string);
                if(!empty(array_intersect($array, $string_to_array))){
                    return TRUE;
                }  else {
                    return FALSE;
                }
            }
        }
    }
    /**
     * 清空RBAC的缓存
     * @return rbac_authorize
     */
    public function clear_cache(){
        $this->_cacher->clear();
        return $this;
    }
    /**
     * 删除指定授权信息
     * @param array $a_user 用户信息array('uid'=>id,'access_password'=>password,...)
     * @param array $a_resource 资源信息array('rtid'=>rtid,'ownerid'=>ownerid,...)
     * @param integer $i_operationid 操作ID
     * @param bool $is_supper 删除的是否是超级管理员的授权，默认为否。
     * @return rbac_authorize
     */
    public function delete_cache($a_user,$a_resource,$i_operationid,$is_supper=FALSE){
        $type=$is_supper?'_check_supperadmin':'_check_permission';
        $authorize_check_key=$type.$a_user['uid'].$a_resource['rtid'].$i_operationid;
        $this->_cacher->delete($authorize_check_key);
        $behaviour=array();
        $this->_rbac_reader->get_behaviour($a_resource['rtid'], $i_operationid,$behaviour);
        $this->_rbac_reader->delete_cache_behaviour($a_resource['rtid'], $i_operationid);
        if(!$is_supper){
            $this->_rbac_reader->delete_cache_owner_group($a_user['uid']);
            $this->_rbac_reader->delete_cache_user_group($a_user['uid']);
            !empty($behaviour)
            && $this->_rbac_reader->delete_cache_user_is_authorize($a_user['uid'], $behaviour['bid']);
            $this->_rbac_reader->delete_cache_user_role($a_user['uid']);
        }
        return $this;
    }
    private function _cache_check($type,$a_user,$a_resource,$i_operationid){
        $authorize_check_key=$type.$a_user['uid'].$a_resource['rtid'].$i_operationid;
        $result=array();
        if($this->_cacher->fetch($authorize_check_key, $result)){
            $this->_error_code=$result['error_code'];
            return $result['permission'];
        }
        $result['permission']=$this->$type($a_user, $a_resource, $i_operationid);
        $result['error_code']=$this->_error_code;
        $this->_cacher->store($authorize_check_key, $result,86400);
        return $result['permission'];
    }
}