<?php
!defined('in_monkey') && exit('Access Denied');
/**
 * rbac_install
 * @category   权限数据库安装
 * @package    权限包
 * @author     HuangYi
 * @copyright  Copyright (c) 2012-4-1——至今
 * @license    New BSD License
 * @version    $Id: rbac_install.class.php 版本号 2012-4-1 $
 *
 */
class rbac_install {
    /**
     * 安装权限数据库
     * @param array $db_config 数据库连接配置
     * @return boolean
     */
    public static function load_db($db_config=null){
        $check_file=__TEMP__.'/rbac/mkRBAC_installed.php';
        if(file_exists($check_file)) return TRUE;
        $sql_file=  dirname(__FILE__).'/data/rbac.sql';
        if(!file_exists($sql_file)) return FALSE;//不存在sql这个文件，错误退出

        $backuper=new db_ghost(dirname(__FILE__).'/data',$db_config);
        if($backuper->import_sql_file($sql_file,'mk_', mk::$ini['db']['prefix'])){
            return TRUE;
        }  else {
            return FALSE;
        }
    }
}