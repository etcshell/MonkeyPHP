<?php
!defined('in_monkey') && exit('Access Denied');
/**
 * rbac_reader
 * @category   权限库读取器
 * @package    权限包
 * @author     HuangYi
 * @copyright  Copyright (c) 2012-7-1- <www.XXXXX.com>
 * @license    New BSD License
 * @version    $Id: rbac_reader.class.php 版本号 2012-7-1_10:43:09  $
 *
 */
class rbac_reader {
    private $_db;//数据库连接对象
    private $_curd;
    private $_cacher;//缓存对象
    public function __construct($rbac_db_read_config=null,$cache_config=null) {
        $this->_db= creater::db($rbac_db_read_config);
        $this->_cacher= creater::cacher('rbac_',$cache_config);
        $this->_curd=  creater::db_curd($this->_db);
    }
    /**
     * 清除RBAC的缓存
     * @return rbac_reader
     */
    public function clear_cache(){
        $this->_cacher->clear();
        return $this;
    }
    /**
     * 获取行为
     * @param int $resource_id  资源类型ID
     * @param int $operation_id 操作ID
     * @param array $behaviour 保存行为的变量
     * @return bool
     */
    public function get_behaviour($resource_id,$operation_id,&$behaviour){
        $sql=  $this->_get_behaviour_sql($resource_id,$operation_id);
        if(!$this->_get_from_cache($sql,$behaviour))return FALSE;
        $behaviour=$behaviour[0];
        return TRUE;
    }
    /**
     * 删除指定行为的缓存
     * @param int $resource_id 资源类型ID
     * @param int $operation_id 操作ID
     * @return \rbac_reader
     */
    public function delete_cache_behaviour($resource_id,$operation_id){
        $sql=  $this->_get_behaviour_sql($resource_id,$operation_id);
        $this->_cacher->delete($sql);
        return $this;
    }
    private function _get_behaviour_sql($resource_id,$operation_id){
        $this->_curd->table('behaviour')->where(
                    'rtid='.intval($resource_id).' AND oid='.intval($operation_id)
                )->limit(3, 0);
        return $this->_curd->make_select();
    }
    /**
     * 获取授权
     * @param int $user_id 用户ID
     * @param int $behaviour_id 行为ID
     * @return bool 有授权为true
     */
    public function user_is_authorize($user_id,$behaviour_id){
        $sql=  $this->_user_is_authorize_sql($user_id, $behaviour_id);
        $authorize=array();
        $this->_get_from_cache($sql,$authorize);
        return !empty($authorize);
    }
    /**
     * 删除指定授权的缓存
     * @param int $user_id 用户ID
     * @param int $behaviour_id 行为ID
     * @return \rbac_reader
     */
    public function delete_cache_user_is_authorize($user_id,$behaviour_id){
        $sql=  $this->_user_is_authorize_sql($user_id,$behaviour_id);
        $this->_cacher->delete($sql);
        return $this;
    }
    private function _user_is_authorize_sql($user_id,$behaviour_id){
        $sql='SELECT {user}.uid,{authorize}.bid
              FROM {user}, {userrole},{authorize}
              WHERE {user}.uid = '.intval($user_id).' AND {user}.is_action = "Y"
                    AND {userrole}.uid = {user}.uid
                    AND '.__time__.' > {userrole}.start AND '.__time__.' < {userrole}.end
                    AND {userrole}.rid = {authorize}.rid
                    AND '.__time__.' > {authorize}.start AND '.__time__.' < {authorize}.end
                    AND {authorize}.bid = '.intval($behaviour_id).'
              UNION
              SELECT {user}.uid,{authorize}.bid
              FROM {user} ,{usergroup} ,{grouprole},{authorize}
              WHERE {user}.uid = '.intval($user_id).'  AND {user}.is_action = "Y"
                    AND {usergroup}.uid={user}.uid
                    AND {usergroup}.gid = {grouprole}.gid AND {grouprole}.`enable` = "Y"
                    AND {grouprole}.rid = {authorize}.rid
                    AND '.__time__.' > {authorize}.start AND '.__time__.' < {authorize}.end
                    AND {authorize}.bid = '.intval($behaviour_id).'
              ';
        return $sql;
    }
    /**
     * 获取用户管理的组
     * @param int $user_id 用户ID
     * @return array 不是组管理员时为空
     */
    public function get_owner_group($user_id){
        $sql=  $this->_get_owner_group_sql($user_id);
        $owner_group=array();
        $this->_get_from_cache($sql,$owner_group);
        mk_array_flatten($owner_group);
        return $owner_group;
    }
    /**
     * 删除指定用户管理的组缓存
     * @param int $user_id 用户ID
     * @return \rbac_reader
     */
    public function delete_cache_owner_group($user_id){
        $sql=  $this->_get_owner_group_sql($user_id);
        $this->_cacher->delete($sql);
        return $this;
    }
    private function _get_owner_group_sql($user_id){
        $sql='SELECT {usergroup}.gid
              FROM {user} ,{usergroup},{group}
              WHERE {user}.uid = '.intval($user_id).'  AND {user}.is_action = "Y"
                    AND {usergroup}.uid={user}.uid AND {usergroup}.gid={group}.gid
                    AND {group}.admin_uid='.intval($user_id).'
              ';
        return $sql;
    }
    /**
     * 获取用户所在的组
     * @param int $user_id 用户ID
     * @return array 非组成员为空
     */
    public function get_user_group($user_id){
        $sql=  $this->_get_user_group_sql($user_id);
        $group=array();
        $this->_get_from_cache($sql,$group);
        mk_array_flatten($group);
        return $group;
    }
    /**
     * 删除指定用户的组缓存
     * @param int $user_id 用户ID
     * @return \rbac_reader
     */
    public function delete_cache_user_group($user_id){
        $sql=  $this->_get_user_group_sql($user_id);
        $this->_cacher->delete($sql);
        return $this;
    }
    private function _get_user_group_sql($user_id){
        $sql='SELECT {usergroup}.gid
              FROM {user} ,{usergroup}
              WHERE {user}.uid = '.intval($user_id).'  AND {user}.is_action = "Y"
                    AND {usergroup}.uid={user}.uid
              ';
        return $sql;
    }
    /**
     * 获取用户的角色
     * @param int $user_id 用户ID
     * @return array 未分配角色时为空
     */
    public function get_user_role($user_id){
        $sql=  $this->_get_user_role_sql($user_id);
        $role=array();
        $this->_get_from_cache($sql,$role);
        mk_array_flatten($role);
        return $role;
    }
    /**
     * 删除指定用户的角色缓存
     * @param int $user_id 用户ID
     * @return \rbac_reader
     */
    public function delete_cache_user_role($user_id){
        $sql=  $this->_get_user_role_sql($user_id);
        $this->_cacher->delete($sql);
        return $this;
    }
    private function _get_user_role_sql($user_id){
        $sql='SELECT {userrole}.rid
              FROM {user}, {userrole}
              WHERE {user}.uid = '.intval($user_id).'
                    AND {user}.is_action = "Y"
                    AND {userrole}.uid = {user}.uid
                    AND '.__time__.' > {userrole}.start AND '.__time__.' < {userrole}.end
              UNION
              SELECT {grouprole}.rid
              FROM {user} ,{usergroup} ,{grouprole}
              WHERE {user}.uid = '.intval($user_id).'  AND {user}.is_action = "Y"
                    AND {usergroup}.uid={user}.uid AND {usergroup}.gid ={grouprole}.gid
                    AND {grouprole}.enable = "Y"
              ';
        return $sql;
    }
    private function _get_from_cache($sql,&$result){
        if($this->_cacher->fetch($sql, $result)) return TRUE;
        if(!$this->_db->query($sql)) return FALSE;
        $result= $this->_db->get_query_result();
        $this->_cacher->store($sql, $result, 86400);
        return TRUE;
    }
}